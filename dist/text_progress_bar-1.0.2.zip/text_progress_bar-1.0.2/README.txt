text_progress_bar
======================


Implementation of a simple text progress bar.

It looks something like this:

[================..............] : downloading xyz (186/335)

distributions can be found on pypi:
* https://pypi.python.org/pypi?:action=display&name=text_progress_bar

